"""
Assignment #9, Part 2
Andrew Park
"""

def valid_username(string):
    #set a string to match the input to.
    lower = 'abcdefghijklmnopqrstuvwxyz'
    #boolean variables
    alphabet = False
    digit = False
    valid = False
    #check if string is 5 characters or longer and if it is, make sure the first char is a digit
    if len(string) >= 5:
            if string[0].isdigit():
                valid = False
            else:
                #go through the string supplied.
                if string.isalnum():
                    for i in string:
                        #make sure everything is alphabet
                        if i in lower:
                            alphabet = True
                        #check if it's a number
                        if i.isdigit():
                            digit = True
                        if alphabet or digit == True:
                            valid = True
                            break
                else:
                    valid = False
    else:
        valid = False

    return valid

""" print( valid_username('abc123') )    # True
print( valid_username('abcde')  )    # True
print( valid_username('abc')    )    # False
print( valid_username('@#$%^')  )    # False
print( valid_username('1abcde') )    # False
print( valid_username('')       )    # False
print() """

def valid_password(string):
    #same as username
    lower = 'abcdefghijklmnopqrstuvwxy'
    Upper = lower.upper()
    #variable counter for lowercase, digit and uppercase
    lc = uc = d = 0
    valid = False
    #check if string is 5 char or longer and is alphanumeric
    if len(string) >= 5 and string.isalnum():
        #check every value in the username (string)
        for i in string:
            #start comparing and making sure it's in the alphabet
            #check if it's lowercase
            if i in lower:
                lc = 1
            #check if it's uppercase
            if i in Upper:
                uc = 1
            #check if it's a number
            if i.isdigit():
                d = 1
            if lc + d + uc == 3:
                valid = True
                break

    return valid

""" print( valid_password('Abc123')     )   # True
print( valid_password('Abc123xyz')  )   # True
print( valid_password('Ab12')       )   # False
print( valid_password('abc123')     )   # False
print( valid_password('123456')     )   # False
print( valid_password('Abc123#')    )   # False
print( valid_password('')           )   # False """

def username_exists(username):
        exists = False
        file = open('user_info.txt','r')
        for i in file:
                user,passwrd = i.strip().split(',')
                x = user
                if(x == username):
                        exists = True
                        break
        file.close()
        return exists     

# print( username_exists('pikachu')           )   # True
# print( username_exists('charmander')        )   # True
# print( username_exists('squirtle')          )   # True
# print( username_exists('Pidgey2020')        )   # True
# print( username_exists('SquirtleSquad99')   )   # False
# print( username_exists('eevee')             )   # False
# print( username_exists('bobcat')            )   # False
# print( username_exists('')                  )   # False
# print()

def check_password(username,password):
        matchFound = False
        file = open('user_info.txt','r')
        for i in file:
                user,passwrd = i.strip().split(',')
                if(user == username and passwrd == password):
                        matchFound = True
                        break
        file.close()
        return matchFound


# print( check_password('pikachu', 'Abc123')              )    # True
# print( check_password('squirtle', 'SquirtleSquad99')    )    # True
# print( check_password('fearow', 'Pqr123')               )    # False
# print( check_password('foobar', 'Hello123')             )    # False
# print( check_password('', '')                           )    # False

def add_user(username,password):
    #assume they aren't in the file
    inthefile = False
    #assume it's not in the file and add them to it (if not in)
    if(not username_exists(username)):
        #open the file and 'a' = append (add)
        with open('user_info.txt','a') as file:
        #write the inputs if it's not in the file already
            file.write('\n' + username +','+ password)

        #welcome message
        send_message('admin',username,'Welcome to your account!')
        inthefile = True

    return inthefile

# add_user('foobar', 'abcABC123')
# add_user('barfoo', 'xyz123ABC')
# add_user('foobar', 'aTest123') # this should fail

import datetime
def send_message(sender, recipient, message):
        d = datetime.datetime.now()
        date = (d.strftime("%m-%d-%y %H:%M:%S").replace('-','/'))
        message_data = '|'.join([sender,date,message+'\n'])
        if(username_exists(recipient)):
                with open('messages/'+recipient+'.txt','a') as file:
                        file.write(message_data)
        else:
                with open('messages/newMessage.txt','a') as file:
                        file.write(message_data)

# send_message('pikachu', 'charmander', 'Hey there!')
# send_message('charmander', 'pikachu', 'Good to see you!')
# send_message('pikachu', 'charmander', 'You too, ttyl')

def print_messages(username):
        with open('messages/'+username+'.txt','r') as file:
                count = 1
                for data in file:
                        if(len(data)<=1):
                            break
                        name,time,message = data.strip().split('|')
                        print("Message #{} received from {}".format(count,name))
                        print("Time:",time)
                        print(message)
                        print()
                        count += 1

# print_messages('charmander')

def delete_messages(username):

        #subsitutte files with an empty one.
        with open('messages/'+username+'.txt','w'):
                pass

# delete_messages('pikachu')

#MAIN FUNCTION
def main():
    #while loop
    while True:
        #user choice
        user_choice = input("(l)ogin, (r)egister or (q)uit: ").lower()
        print()
        
        #go through all 3 options
        if user_choice == 'l':
            print()
            print("Log in")
            #enter user and pass
            user_name = input("Username (Case sensitive): ")
            passwrd = input("Password (Case sensitive): ")
            
            #make sure both inputs are valid
            if check_password(user_name, passwrd):
                
                #loop when logged in successfully
                while True:
                    print("You have been logged in successfully as", user_name)
                    #after it is verified, give them the main options within the account
                    choice = input("(r)ead messages, (s)end a message, (d)elete messages or (l)ogout: ").lower()
                    
                    #read message
                    if choice=='r':
                        print()
                        with open('messages/'+user_name+'.txt', 'r+') as f:
                            f.seek(0)
                            if f.read() == "":
                                print("No messages in your inbox")
                                print()
                            else:
                                print_messages(user_name)
                    
                    #send message
                    elif choice=='s':
                        
                        #who to send and what.
                        recipient = input("Username of recipient: ")
                        if username_exists(recipient):
                            msg = input("Type your message: ")
                            print("Message sent!")
                            print()
                            send_message(user_name,recipient, msg)
                        else:
                            print("Unknown recipient")
                            print()

                        
                    #delete msg
                    elif choice=='d':
                        print("Your messages have been deleted")
                        print()
                        
                        #calling delete_messages function
                        delete_messages(user_name)
                        
                    # log out and end program
                    elif choice=='l':
                        print("Logged out")
                        print()
                        break
                        
                    #if none of the options are selected
                    else:
                        print("Wrong choice.")
                        
            #invalid user/pass
            else:
                print("Invalid user name or password.")
            
        #register account
        elif user_choice == 'r':
            print("Register for an account")
            
            user_name = input("Username (Case sensitive): ")
            passwrd = input("Password (Case sensitive): ")
            
            #validate inputs
            if valid_password(passwrd) and valid_username(user_name):
                
                #checking whether user already exist
                if add_user(user_name, passwrd):
                    print("Registration successful!")
                    print()
                else: 
                    print("Duplicate username, registration cancelled")
                    print()
                    
            else:
                print("Password is invalid, registration cancelled")
                print()
                
        #break loop if quit
        elif user_choice == 'q':
            print("quit")
            break
        
        else:
            print("You entered wrong choice.")
        
if __name__=="__main__":
    main()



